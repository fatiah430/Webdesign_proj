<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP Example</title>
</head>
<body>
    <?php // use php open and close tag to be php, happen in apache
    
    /*
    print "hello, world!"; // semicolons are required
    $var1 = "hello"; //variables start with a $
    $var2 = "world";

    print "$var1 <br> $var2";

    print "<br>";

    print $var1.$var2; //concation with perios insted of a +
    print "$var1 ---- $var2";
    */
    /*
    $myarray = array(10,20,30,40);
    array_push($myarray, 20);
    print var_dump($myarray);

    sizeof() -> is the same as ().length
    */

    /*
    this is a dictionary
    $myarray = array();
    $myarray['name'] = 'pica';
    $myarray['power'] = 'thunder';
    */

    
    ?>
    
</body>
</html>