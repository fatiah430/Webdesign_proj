<?php
    //grab data from the user 
    $title = $_POST['title'];
    $year = $_POST['year'];

    //connect to datatbase
    $dbpath = '/home/faj9393/database/movies.db';
    $db = new SQLite3($dbpath);

    // Check if the title and year have been provided
    if (empty($title) || empty($year)) {
        // Display error message and redirect back to the form
        header("Location: add_form.php?error=missing_data");
        exit();
    }

    // Validate the year input to make sure it's a number
    if (!is_numeric($year)) {
        // Display error message and redirect back to the form
        header("Location: add_form.php?error=invalid_year");
        exit();
    }

    //insert a record into our table
    $sql = "INSERT INTO movies (title,year) VALUES (:title, :year)";
    $statement = $db->prepare($sql);
    $statement->bindValue(':title', $title);
    $statement->bindValue(':year', $year);
    $statement->execute();

    // Close the database connection
    $db->close();

    //redirect the user back to the form with a success message
    header("location: add_form.php?success=movie_added");
    exit();


    

?>



