<?php
    include('header.php');

    // retrieve the movie id from the GET request
    $id = $_GET['id'];

    // connect to the database
    $dbpath = '/home/faj9393/database/movies.db';
    $db = new SQLite3($dbpath);

    // delete the movie with the given id from the movies table
    $sql = "DELETE FROM movies WHERE id = :id";
    $statement = $db->prepare($sql);
    $statement->bindValue(':id', $id);
    $statement->execute();

    // display a confirmation message to the user
    header("location: index.php?success=deleted");

    $db->close();
    unset($db);
?>
