<!doctype html>
<html>
    <head>
        <title>Movie Database</title>
        <style>
            #error, #success {
                padding: 10px;
                margin-bottom: 20px;
                text-align: center;
                color: white;
                font-size:30px;
            }

            #error {
                background-color: #FF4136;
            }

            #success {
                background-color: #9cba8f;
            }

            /* style the form */
            form {
                margin: 50px auto;
                max-width: 500px;
                padding: 20px;
                border: 1px solid #DDD;
                border-radius: 5px;
                box-shadow: 0 0 5px #DDD;
            }

            form input[type="text"] {
                width: 100%;
                padding: 10px;
                margin-bottom: 20px;
                border: 1px solid #DDD;
                border-radius: 5px;
                font-size: 16px;
            }

            form input[type="submit"] {
                background-color: #0074D9;
                color: white;
                padding: 10px 20px;
                border: none;
                border-radius: 5px;
                font-size: 16px;
                cursor: pointer;
            }

            form input[type="submit"]:hover {
                background-color: #0E5A8A;
            }
        </style>
    </head>
    <body>
        <!-- <h1>My Movie Database: Add</h1> -->
        
        <?php
            include('header.php');

            if ($_GET['error'] == 'missing_data') {
                echo '<div id="error">Please answer all questions before submitting the form.</div>';
            }
            if ($_GET['error'] == 'invalid_year') {
                echo '<div id="error">The year is incorrect.</div>';
            }
            if ($_GET['success'] == 'movie_added') {
                echo '<div id="success">The movie added successfully.</div>';
            }

        ?>
        <form method="POST" action="add_save.php">
            Title: <input type="text" name="title"><br>
            Year: <input type="text" name="year"><br>
            <input type="submit" value="Add Movie">
        </form> 


    </body>

</html>