<!doctype html>
<html>
    <head>
        <title>Movie Search</title>
        <style>
            /* style the form */
            form {
                display: flex;
                flex-direction: column;
                width: 300px;
                margin: 0 auto;
                padding: 20px;
                border: 2px solid #ccc;
                border-radius: 5px;
            }

            label {
                font-weight: bold;
                margin-bottom: 10px;
            }

            input[type="text"] {
                padding: 10px;
                border: 1px solid #ccc;
                border-radius: 5px;
                margin-bottom: 20px;
            }

            input[type="submit"] {
                padding: 10px 20px;
                background-color: #007bff;
                color: #fff;
                border: none;
                border-radius: 5px;
                cursor: pointer;
            }

            input[type="submit"]:hover {
                background-color: #0062cc;
            }

            table {
			border-collapse: collapse;
			width: 100%;
			margin-bottom: 20px;
            }

            th, td {
                border: 1px solid #ccc;
                padding: 10px;
                text-align: left;
            }

            th {
                background-color: #eee;
            }


        
        </style>
    </head>
    <body>
    <!-- <h1>My Movie Database: Add</h1> -->
    <?php
        include('header.php');
    ?>
    <form method="POST" action="search_form.php">
        Title: <input type="text" name="title"><br>
        Year: <input type="text" name="year"><br>
        <input type="submit" value="Search">
    </form>

    <?php
    if (isset($_POST['title']) || isset($_POST['year'])) {
        // Get the search term values from the GET request
        $title = isset($_POST['title']) ? $_POST['title'] : '';
        $year = isset($_POST['year']) ? $_POST['year'] : '';

        // Connect to database
        $dbpath = '/home/faj9393/database/movies.db';
        $db = new SQLite3($dbpath);

        // Set up SQL query with placeholders
        $sql = "SELECT id, title, year FROM movies WHERE 1=1";

        // Prepare the SQL statement with placeholders
        if (!empty($title)) {
            $sql .= " AND title LIKE :title";
        }
        if (!empty($year)) {
            $sql .= " AND year LIKE :year";
        }
        $st = $db->prepare($sql);

        // Bind the search terms to the placeholders
        if (!empty($title)) {
            $st->bindValue(':title', '%'.$title.'%', SQLITE3_TEXT);
        }
        if (!empty($year)) {
            $st->bindValue(':year', '%'.$year.'%', SQLITE3_TEXT);
        }

        // Execute the statement and get the result set
        $result = $st->execute();

        // Loop through the results and display them to the user
        echo '<table>';
        echo '<tr><th>ID</th><th>Title</th><th>Year</th></tr>';
        while ($row = $result->fetchArray()) {
            echo '<tr>';
            echo '<td>' . $row['id']; '</td>';
            echo '<td>'. $row['title']; '</td>';
            echo '<td>'. $row['year']; '</td>';
            echo '</tr>';
        }
        echo '</table>';

        // Close the database connection
        $db->close();
    }
    ?>


</body>


</html>











