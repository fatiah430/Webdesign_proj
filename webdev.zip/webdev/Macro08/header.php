<style>
    #navigation {
        background-color: #d27575;
        overflow: hidden;
    }

    #navigation a {
        float: left;
        display: block;
        color: white;
        text-align: center;
        padding: 16px 18px;
        text-decoration: none;
        font-size: 40px;   
    }

    #navigation a:hover {
        background-color: #ddd;
        color: black;
    }

</style>

<div id="navigation">
    <a href="index.php">View All Movies</a>
    <a href="add_form.php">Add a Movie</a>
    <a href="search_form.php">Search for a Movie</a>
</div>
