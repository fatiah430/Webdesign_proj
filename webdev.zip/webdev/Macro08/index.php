<!doctype html>
<html>
    <head>
        <title>Movie Database</title>
        <style>
            body {
			font-family: Arial, sans-serif;
			background-color: #f5f5f5;
			padding: 20px;
			margin: 0;
		}

		h1 {
			color: #333;
			margin-bottom: 20px;
		}

		#success, #error {
			padding: 10px;
			margin-bottom: 20px;
			border-radius: 5px;
		}

		#success {
			background-color: #c1e1c1;
			color: #007700;
		}

		#error {
			background-color: #f8c1c1;
			color: #770000;
		}

		table {
			border-collapse: collapse;
			width: 100%;
			margin-bottom: 20px;
		}

		th, td {
			border: 1px solid #ccc;
			padding: 10px;
			text-align: left;
		}

		th {
			background-color: #eee;
		}

		a:hover {
			text-decoration: underline;
		}

		form {
			background-color: #fff;
			padding: 20px;
			border-radius: 5px;
			margin-bottom: 20px;
		}

		input[type=text], input[type=password], input[type=email] {
			width: 100%;
			padding: 10px;
			border-radius: 5px;
			border: 1px solid #ccc;
			margin-bottom: 10px;
			box-sizing: border-box;
		}

		input[type=submit] {
			background-color: #007700;
			color: #fff;
			padding: 10px;
			border-radius: 5px;
			border: none;
			cursor: pointer;
		}

		input[type=submit]:hover {
			background-color: #005500;
		}

		#navigation {
			background-color: #333;
			padding: 10px;
			margin-bottom: 20px;
		}

		#navigation a {
			color: #fff;
			margin-right: 10px;
		}

        </style>
    </head>
    <body>
        <?php
            include('header.php');
        ?>

        <?php
            if ($_GET['success'] == 'deleted') {
                echo '<div id="success">The movie was deleted successfully.</div>';
            }

            // Connect to database
            $dbpath = '/home/faj9393/database/movies.db';
            $db = new SQLite3($dbpath);

            // Set up a SQL query to get all movies from the table
            $sql = "SELECT id, title, year FROM movies";
            $statement = $db->prepare($sql);
            $result = $statement->execute();

            // Generate table to display movie data
            echo '<table>';
            echo '<tr><th>ID</th><th>Title</th><th>Year</th><th>Delete</th></tr>';
            while($array = $result->fetchArray()){
                echo '<tr>';
                echo '<td>' . $array['id'] . '</td>';
                echo '<td>' . $array['title'] . '</td>';
                echo '<td>' . $array['year'] . '</td>';
                echo '<td><a href="delete.php?id=' . $array['id'] . '">Delete</a></td>';
                echo '</tr>';
            }
            echo '</table>';

            $db->close();
            unset($db);
        ?>

        



    </body>

</html>






