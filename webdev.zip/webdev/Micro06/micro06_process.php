<?php
   if(empty($_POST['username'])) {
     // Redirect back to micro06.php with a GET variable and exit script
     header("Location: micro06.php?error=username_missing");
     exit;
   }
   // If username is not missing, continue with your code here
   
   if(empty($_POST['password'])) {
    // Redirect back to micro06.php with a GET variable and exit script
    header("Location: micro06.php?error=password_missing");
    exit;
  }

  $username = $_POST['username'];
  $password = $_POST['password'];

  if($username !== 'pikachu' || $password !== 'pokemon') {
  // Redirect back to micro06.php with a GET variable and exit script
  header("Location: micro06.php?error=invalid_credentials");
  exit;
 } else {
    header("Location: micro06.php?login=success");
    exit;
 }





?>