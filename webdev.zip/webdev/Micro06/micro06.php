<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=<, initial-scale=1.0">
    <title>PHP</title>
    <style>
        /* micro06.css */
        form {
        width: 50%;
        margin: 0 auto;
        padding: 20px;
        border: 1px solid #ccc;
        border-radius: 5px;
        }

        label {
        display: inline-block;
        width: 100px;
        margin-bottom: 10px;
        }

        input[type="text"],
        input[type="password"] {
        display: block;
        width: 100%;
        padding: 10px;
        border-radius: 5px;
        border: 1px solid #ccc;
        margin-bottom: 20px;
        }

        input[type="submit"] {
        display: block;
        width: 100%;
        padding: 10px;
        background-color: #4CAF50;
        color: white;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        }

        input[type="submit"]:hover {
        background-color: #3e8e41;
        }
    </style>
</head>
<body>
<?php
	if(isset($_GET['error'])) {
		if($_GET['error'] === 'missing_username') {
			echo '<p style="color: red;">Error: Please enter a username.</p>';
		} else if($_GET['error'] === 'missing_password') {
			echo '<p style="color: red;">Error: Please enter a password.</p>';
		} else if($_GET['error'] === 'invalid_credentials') {
			echo '<p style="color: red;">Error: Invalid username/password combination.</p>';
		}
	} else if(isset($_GET['login'])) {
		if($_GET['login'] === 'success') {
			echo '<p style="color: green;">Welcome to the page.</p>';
		}
	}
	?>
    <form action="micro06_process.php" method="POST">
        <label for="username">Username:</label>
        <input type="text" name="username" id="username">

        <label for="password">Password:</label>
        <input type="password" name="password" id="password">

        <input type="submit" value="Submit">
    </form>
    

</body>
</html>