<!DOCTYPE html>
<html lang="en">
<head>
    <title>QUIZ!</title>
    <style>
        #error{
            background-color: red;
            color: white;
            padding: 10px;
            font-size: 200%;
            text-align: center;
        }
        body {
            background-color: #FFB6C1;
            font-family: Arial, sans-serif;
        }
        .quiz-header {
            text-align: center;
        }
        form {
            margin: 50px auto;
            width: 400px;
            background-color: #FFFFFF;
            border-radius: 5px;
            padding: 20px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }

        select {
            padding: 8px;
            border-radius: 3px;
            border: 1px solid #CCCCCC;
            width: 100%;
            margin-bottom: 15px;
        }

        button {
            background-color: #FF6600;
            color: #FFFFFF;
            padding: 10px 20px;
            border: none;
            border-radius: 3px;
            font-size: 16px;
            cursor: pointer;
        }

        button:hover {
            background-color: #FF8533;
        }

    </style>
</head>
<body>
    <div class="quiz-header">
      <h1>TAKE MY QUIZ!</h1>
    </div>

    <?php
    if ($_GET['error'] == 'missed_question') {
        echo '<div id="error">"Please answer all questions before submitting the form."</div>';
    }
    ?>
	<form action="save.php" method="POST">
        What is your favorite color?<br>
        <select name="color">
            <option value="">Select an answer</option>
            <option value="y">Yellow</option>
            <option value="g">Green</option>
            <option value="b">Blue</option>
            <option value="o">Orange</option>
        </select><br><br>
        
        What is your dessert food?<br>
        <select name="dessert">
            <option value="">Select an answer</option>
            <option value="icecream">Ice Cream</option>
            <option value="donuts">Donuts</option>
            <option value="cookies">Cookies</option>
            <option value="tarts">Tarts</option>
        </select><br><br>
        
        What is your favorite hobby?<br>
        <select name="hobby">
            <option value="">Select an answer</option>
            <option value="knitting">Knitting</option>
            <option value="binge">Binge Watching</option>
            <option value="reading">Reading</option>
            <option value="skateboarding">Skateboarding</option>
        </select><br><br>
        
        What is your biggest fear?<br>
        <select name="fear">
            <option value="">Select an answer</option>
            <option value="heights">Heights</option>
            <option value="flying">Flying</option>
            <option value="spiders">Spiders</option>
            <option value="snakes">Snakes</option>
        </select><br><br>
        
        <button type="submit">What Simpsons Character am I?</button>
    </form>

    
    
    
</body>
</html>