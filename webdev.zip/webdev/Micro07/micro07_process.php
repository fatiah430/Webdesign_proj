<?php
$path ='/Users/fatiahjimoh/Documents/MAMP/webdev/Micro07/data/file.txt';

  
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];
    if (empty($username) || empty($password)){
        file_put_contents($path, "\tmissing\n", FILE_APPEND);
        header('Location: micro07.php?error=missing');
        exit;
    }
    if ($username === 'pikachu' && $password === 'pokemon') {
        file_put_contents($path, "\tsuccess\n", FILE_APPEND);
        header('Location: micro07.php?login=success');
        setcookie('logged_in', 'true');
        exit;
    } else {
        file_put_contents($path, "\tunsuccessful\n", FILE_APPEND);
        header('Location: micro07.php?error=unsuccessful');
        exit;
    }

}

  




?>