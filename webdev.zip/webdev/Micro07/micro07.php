<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=<, initial-scale=1.0">
    <title>PHP</title>
    <style>
        /* micro07.css */
        form {
        width: 50%;
        margin: 0 auto;
        padding: 20px;
        border: 1px solid #ccc;
        border-radius: 5px;
        }

        label {
        display: inline-block;
        width: 100px;
        margin-bottom: 10px;
        }

        input[type="text"],
        input[type="password"] {
        display: block;
        width: 95%;
        padding: 10px;
        border-radius: 5px;
        border: 1px solid #ccc;
        margin-bottom: 20px;
        }

        input[type="submit"] {
        display: block;
        width: 100%;
        padding: 10px;
        background-color: #4CAF50;
        color: white;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        }

        input[type="submit"]:hover {
        background-color: #3e8e41;
        }
    </style>
</head>
<body>
<?php
	if(isset($_GET['error'])) {
		if($_GET['error'] === 'missing') {
			echo '<p style="color: red;">Error: please enter a correct username and password</p>';
		} elseif($_GET['error'] === 'unsuccessful'){
            echo '<p style="color: red;">Error: Invalid username or password</p>';
        }
	} 
    if (isset($_COOKIE['logged_in']) && $_COOKIE['logged_in'] === 'true') {
        echo '<p style="color: green;">You are logged in.</p>';
        exit;
    }

	?>
    <form action="micro07_process.php" method="POST">
        <label for="username">Username:</label>
        <input type="text" name="username" id="username">

        <label for="password">Password:</label>
        <input type="password" name="password" id="password">

        <input type="submit" value="Submit">
    </form>
    

</body>
</html>